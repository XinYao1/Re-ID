from __future__ import print_function, absolute_import
import argparse
import os.path as osp
import random
import numpy as np
import sys
from glob import glob
import torch
from torch import nn
from torch.backends import cudnn
from torch.utils.data import DataLoader
from PIL import Image
from tqdm import tqdm
from clustercontrast import datasets
from clustercontrast import models
from clustercontrast.models.dsbn import convert_dsbn, convert_bn
from clustercontrast.evaluators import Evaluator
from clustercontrast.utils.data import transforms as T
from clustercontrast.utils.data.preprocessor import Preprocessor1
from clustercontrast.utils.logging import Logger
from clustercontrast.utils.serialization import load_checkpoint, save_checkpoint, copy_state_dict
from collections import OrderedDict
import  os
import shutil


input_img = '查询人员/person4.jpg'         #要查询的照片
regis_path = '注册库'                   #注册库
regis_imgs = glob(regis_path+'/*.jpg')  #注册库的照片
n = 5   #找到最相似的n个人
def to_torch(ndarray):
    if type(ndarray).__module__ == 'numpy':
        return torch.from_numpy(ndarray)
    elif not torch.is_tensor(ndarray):
        raise ValueError("Cannot convert {} to torch tensor"
                         .format(type(ndarray)))
    return ndarray

def get_data(imgs,height=256, width=128, batch_size=256, workers=0):


    normalizer = T.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])

    test_transformer = T.Compose([
             T.Resize((height, width), interpolation=3),
             T.ToTensor(),
             normalizer
         ])

    test_loader = DataLoader(
        Preprocessor1(list(imgs),
                     root='D:/ai2/cluster-contrast-reid/examples/', transform=test_transformer),
        batch_size=batch_size, num_workers=workers,
        shuffle=False, pin_memory=True)
    return test_loader

def extract_cnn_feature(model, inputs):
    inputs = to_torch(inputs).cuda()
    outputs = model(inputs)
    outputs = outputs.data.cpu()
    return outputs

normalizer = T.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
test_transformer = T.Compose([
         T.Resize((256, 128), interpolation=3),
         T.ToTensor(),
         normalizer
     ])

cudnn.benchmark = True
# Create data loaders
# dataset, test_loader = get_data(args.dataset, args.data_dir, args.height,args.width, args.batch_size, args.workers)

# Create model
model = models.create('resnet50', pretrained=False, num_features=0, dropout=0,
                          num_classes=0, pooling_type='gem')
# Load from checkpoint
checkpoint = load_checkpoint('../cluster-contrast/market-res50/logs/model_best.pth.tar')
copy_state_dict(checkpoint['state_dict'], model, strip='module.')
model.cuda()
model = nn.DataParallel(model)
res_loader = get_data(imgs=regis_imgs)
test_loader = get_data(imgs=[input_img])
# Evaluator
model.eval()
features_res = OrderedDict()

features_cha = OrderedDict()
print('查询照片提取特征')
with torch.no_grad():
    for (imgs, fnames, pids) in tqdm(test_loader):
        outputs = extract_cnn_feature(model, imgs)
        for fname, output, pid in zip(fnames, outputs, pids):
            features_cha[fname] = output

if not osp.exists('features_res.pth'):
    print('注册库提取特征')
    with torch.no_grad():
        for (imgs, fnames, pids) in tqdm(res_loader):
            outputs = extract_cnn_feature(model, imgs)
            for fname, output, pid in zip(fnames, outputs, pids):
                features_res[fname] = output
    torch.save(features_res,'features_res.pth')
else:
    print('导入注册库特征')
    features_res = torch.load('features_res.pth')
x = torch.cat([features_cha[f].unsqueeze(0) for f in [input_img]], 0)
y = torch.cat([features_res[f].unsqueeze(0) for f in regis_imgs], 0)
distance = torch.cdist(x,y)
top_similar_indices = torch.argsort(distance,dim=1)[0][:n]
save_path = '查询结果/'+input_img.split('/')[1].split('.')[0]
os.makedirs(save_path,exist_ok=True)
for i in top_similar_indices.tolist():
    shutil.copy(regis_imgs[i],save_path)
print(f'最相似的{n}个人的查询结果已写入到查询结果文件夹中')
print('查询结束')